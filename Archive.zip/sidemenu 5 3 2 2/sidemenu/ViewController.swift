//
//  ViewController.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-07.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//


import MapKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imgImage: UIImageView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       imgImage.loadGif(name: "giphy-22")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    }
    
    
  
        
        
    
    





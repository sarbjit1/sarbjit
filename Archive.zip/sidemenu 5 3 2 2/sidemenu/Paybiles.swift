//
//  Paybiles.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-12.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import Foundation
import UIKit
class Paybiles: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var total: UILabel!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var cardNumber: UITextField!
    var lebaltext = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        total.text = lebaltext
        name.delegate = self
        email.delegate = self
        cardNumber.delegate = self
        
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"  // Recognizes enter key in keyboard
        {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        name.resignFirstResponder()
        email.resignFirstResponder()
        cardNumber.resignFirstResponder()
        return true
    }
}

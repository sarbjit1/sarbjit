//
//  Location.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-07.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit
class Location:UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var map: MKMapView!
    var mapmanager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        mapmanager.delegate = self
        mapmanager.desiredAccuracy = kCLLocationAccuracyBest
        mapmanager.requestAlwaysAuthorization()
        mapmanager.startUpdatingLocation()
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        let zoom:MKCoordinateSpan = MKCoordinateSpanMake(60, 60)
        let mylocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(mylocation, zoom)
        map.setRegion(region, animated: true)
        map.showsUserLocation = true
        
        let brampton = MKPointAnnotation()
        brampton.coordinate = CLLocationCoordinate2DMake(43.729810, -79.759552)
        //43.729810, -79.759552
        brampton.title = "brampton store"
        brampton.subtitle = "visite here"
        map.addAnnotation(brampton)
        
        
        
        //surry   49.105250, -122.801048
        
        let surrey = MKPointAnnotation()
        surrey.coordinate = CLLocationCoordinate2DMake(49.105250, -122.801048)
       
        surrey.title = "surrey store"
        surrey.subtitle = "visite here"
        map.addAnnotation(surrey)
    }
    
    
}

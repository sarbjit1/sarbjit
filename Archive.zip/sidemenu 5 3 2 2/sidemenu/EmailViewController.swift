//
//  EmailViewController.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-11.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import UIKit
import MessageUI

class EmailViewController: UIViewController, MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func emailbtn(_ sender: UIButton) {
        let mailComposeController = MFMailComposeViewController()
        mailComposeController.mailComposeDelegate = self;
        mailComposeController.setToRecipients(["sarbjit0408@gmail.com"])
        mailComposeController.setSubject("paint colour")
        mailComposeController.setMessageBody(" please visit at following address ", isHTML: false)
        
        
        if MFMailComposeViewController.canSendMail(){
            self.present(mailComposeController, animated: true, completion: {
                () -> Void in
            })
        }
        
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true) {  () -> Void in
            
    }
        
    }

    

}

//
//  CollectionViewCell.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-08.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgImage: UIImageView!
    
      @IBOutlet weak var lblNmae: UILabel!
    
    
    
}

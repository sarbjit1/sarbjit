//
//  Viewradio.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-10.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import Foundation
class Viewradio: UIViewController {
    
    
    @IBOutlet weak var total: UITextField!
    @IBOutlet weak var btn: DLRadioButton!
    
    @IBAction func btnAction(_ sender: DLRadioButton) {
        if sender.tag == 1 {
            total.text = "750"
        }else if sender.tag ==  2{
            total.text = "1000"
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       btn.isMultipleSelectionEnabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}

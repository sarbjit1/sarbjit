//
//  CheckBoxView.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-12.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import Foundation
import UIKit
class CheckBoxView: UIViewController {
    
    
    @IBOutlet weak var checkone: UIButton!
    
    @IBOutlet weak var checktwo: UIButton!
    
    
  
    
    @IBOutlet weak var labeltotal: UILabel!
    @IBOutlet weak var labelone: UILabel!
    
    @IBOutlet weak var lebaltwo: UILabel!
    
   
    
    var checkimage = UIImage(named: "check1")
    var uncheckImage = UIImage(named: "check2")
    var isBoxChecked:Bool!
    
    override func viewDidLoad() {
       super.viewDidLoad()
        
    }
    
    @IBAction func checkoneAction(_ sender: Any) {
        if isBoxChecked == true{
            isBoxChecked = false
        }else{
            isBoxChecked = true
        }
        if isBoxChecked == true{
            checkone.setImage(checkimage, for: UIControlState.normal)
            labelone.text = "500"
        }else{
            checkone.setImage(uncheckImage, for: UIControlState.normal)
            labelone.text = " "
        }
        
    }
    
    @IBAction func checktwoAction(_ sender: Any) {
        if isBoxChecked == true{
            isBoxChecked = false
        }else{
            isBoxChecked = true
        }
        if isBoxChecked == true{
            checktwo.setImage(checkimage, for: UIControlState.normal)
            lebaltwo.text = "550"
        }else{
            checktwo.setImage(uncheckImage, for: UIControlState.normal)
            lebaltwo.text = " "
        }
    }
    
 
    
    
    @IBAction func displayTotal(_ sender: Any) {
        if labelone.text == "500" {
           labeltotal.text = "500"
        }
        if lebaltwo.text == "550" {
            labeltotal.text = "550"
        }
        if labelone.text == "500" && lebaltwo.text == "550"{
            labeltotal.text = "1050"
        }
        if labelone.text == " " && lebaltwo.text == " "{
            labeltotal.text = " "
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destViewController: Paybiles = segue.destination as! Paybiles
        destViewController.lebaltext = labeltotal.text!
    }
    
    
}




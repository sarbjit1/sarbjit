//
//  display.swift
//  sidemenu
//
//  Created by Sarb Maan on 2017-11-12.
//  Copyright © 2017 Sarb Maan. All rights reserved.
//

import Foundation
import UIKit
class display: UIViewController {
    
    
    override func viewDidLoad() {
        
    }
    
}
